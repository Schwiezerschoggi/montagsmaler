const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });
app.use(express.static(path.join(__dirname, "public")));
app.get("/health", (_req, res) => res.json({ ok: true }));

const rooms = new Map();
const MAX_PLAYERS = 8;
const WORDS = [
  "Sonnenbrille","Elefant","Feuerwehr","Pizza","Fussball","Zahnbürste","Schneemann",
  "Flugzeug","Einhorn","Polizist","Berg","Kaktus","Roboter","Gitarre","Dinosaurier",
  "Regenschirm","Krankenwagen","Schokolade","Pinguin","Mondlandung","Badeente",
  "Waschmaschine","Ritter","Rakete","Kühlschrank","Wasserfall","Schildkröte","Zirkus",
  "Skateboard","Geburtstagstorte","Schlüssel","Kamera","Biene","Geisterbahn","Leuchtturm"
];

function cleanName(value) {
  return String(value || "Spieler").trim().replace(/[<>]/g, "").slice(0, 18) || "Spieler";
}
function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 5; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}
function publicRoom(room) {
  return {
    code: room.code,
    hostId: room.hostId,
    phase: room.phase,
    round: room.round,
    maxRounds: room.maxRounds,
    drawerId: room.drawerId,
    wordLength: room.word ? room.word.length : 0,
    maskedWord: room.word && room.phase === "playing" ? room.word.replace(/[A-Za-zÄÖÜäöü]/g, "_") : "",
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, score: p.score, connected: p.connected
    })),
    messages: room.messages.slice(-60),
    customWordsCount: room.customWords.length
  };
}
function broadcast(room) {
  io.to(room.code).emit("room:update", publicRoom(room));
}
function sendPrivateWord(room) {
  if (!room.drawerId || !room.word) return;
  io.to(room.drawerId).emit("word:private", { word: room.word });
}
function endRound(room, reason) {
  if (room.phase !== "playing") return;
  clearTimeout(room.roundTimer);
  room.phase = "reveal";
  room.messages.push({ system: true, text: `Runde beendet: ${reason}. Der Begriff war „${room.word}“.` });
  io.to(room.code).emit("round:ended", { word: room.word, reason });
  broadcast(room);
  room.nextTimer = setTimeout(() => nextRound(room), 4500);
}
function nextRound(room) {
  clearTimeout(room.nextTimer);
  const players = [...room.players.values()].filter(p => p.connected);
  if (players.length < 2) {
    room.phase = "lobby";
    room.drawerId = null; room.word = null;
    broadcast(room); return;
  }
  if (room.round >= room.maxRounds * players.length) {
    room.phase = "finished";
    room.drawerId = null;
    io.to(room.code).emit("game:finished", {
      players: players.sort((a,b) => b.score - a.score).map(p => ({ name: p.name, score: p.score }))
    });
    broadcast(room); return;
  }
  room.round++;
  const drawer = players[(room.round - 1) % players.length];
  room.drawerId = drawer.id;
  room.roundStartedAt = Date.now();
  const allWords = [...WORDS, ...room.customWords];
  room.word = allWords[Math.floor(Math.random() * allWords.length)];
  room.phase = "playing";
  room.messages.push({ system: true, text: `Runde ${room.round}: ${drawer.name} zeichnet jetzt!` });
  io.to(room.code).emit("round:started", {
    drawerId: room.drawerId, drawerName: drawer.name, round: room.round,
    duration: 80, wordLength: room.word.length
  });
  sendPrivateWord(room);
  broadcast(room);
  room.roundTimer = setTimeout(() => endRound(room, "Zeit abgelaufen"), 80000);
}
io.on("connection", socket => {
  socket.on("room:create", ({ name }, cb = () => {}) => {
    let code;
    do { code = makeCode(); } while (rooms.has(code));
    const player = { id: socket.id, name: cleanName(name), score: 0, connected: true };
    const room = {
      code, hostId: socket.id, players: new Map([[socket.id, player]]),
      phase: "lobby", round: 0, maxRounds: 2, drawerId: null, word: null,
      messages: [], customWords: [], roundTimer: null, nextTimer: null, strokes: []
    };
    rooms.set(code, room);
    socket.join(code);
    cb({ ok: true, code, playerId: socket.id });
    broadcast(room);
  });

  socket.on("room:join", ({ code, name }, cb = () => {}) => {
    code = String(code || "").trim().toUpperCase();
    const room = rooms.get(code);
    if (!room) return cb({ ok: false, error: "Dieser Raum wurde nicht gefunden." });
    if (room.players.size >= MAX_PLAYERS) return cb({ ok: false, error: "Der Raum ist voll (max. 8 Spieler)." });
    if (room.phase !== "lobby") return cb({ ok: false, error: "Das Spiel läuft bereits. Bitte warte auf die nächste Runde." });
    const player = { id: socket.id, name: cleanName(name), score: 0, connected: true };
    room.players.set(socket.id, player);
    socket.join(code);
    cb({ ok: true, code, playerId: socket.id });
    room.messages.push({ system: true, text: `${player.name} ist beigetreten.` });
    broadcast(room);
  });

  socket.on("game:start", ({ code }, cb = () => {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room) return cb({ ok: false, error: "Raum nicht gefunden." });
    if (room.hostId !== socket.id) return cb({ ok: false, error: "Nur der Host kann das Spiel starten." });
    if (room.players.size < 2) return cb({ ok: false, error: "Mindestens zwei Spieler werden benötigt." });
    if (room.phase !== "lobby" && room.phase !== "finished") return cb({ ok: false, error: "Das Spiel läuft bereits." });
    room.players.forEach(p => p.score = 0);
    room.round = 0; room.strokes = [];
    room.phase = "lobby";
    cb({ ok: true });
    nextRound(room);
  });

  socket.on("chat:send", ({ code, text }, cb = () => {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room || !room.players.has(socket.id)) return;
    const player = room.players.get(socket.id);
    const guess = String(text || "").trim().slice(0, 120);
    if (!guess) return;
    if (room.phase === "playing" && socket.id !== room.drawerId &&
        guess.localeCompare(room.word, "de", { sensitivity: "base" }) === 0) {
      const points = Math.max(10, Math.round(100 - (Date.now() - (room.roundStartedAt || Date.now())) / 1000));
      player.score += points;
      room.messages.push({ system: true, text: `${player.name} hat richtig geraten! +${points} Punkte` });
      io.to(room.code).emit("guess:correct", { playerId: socket.id, name: player.name, points });
      endRound(room, "Begriff erraten");
      broadcast(room);
    } else {
      room.messages.push({ name: player.name, text: guess, system: false });
      io.to(room.code).emit("chat:message", room.messages[room.messages.length - 1]);
      broadcast(room);
    }
    if (typeof cb === "function") cb({ ok: true });
  });

  socket.on("drawing:stroke", ({ code, stroke }) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room || room.phase !== "playing" || room.drawerId !== socket.id || !stroke) return;
    const safe = {
      x0: Number(stroke.x0), y0: Number(stroke.y0), x1: Number(stroke.x1), y1: Number(stroke.y1),
      color: /^#[0-9a-f]{6}$/i.test(stroke.color) ? stroke.color : "#172033",
      width: Math.max(1, Math.min(24, Number(stroke.width) || 4)),
      clear: !!stroke.clear
    };
    if (![safe.x0,safe.y0,safe.x1,safe.y1].every(Number.isFinite)) return;
    room.strokes.push(safe);
    if (room.strokes.length > 2500) room.strokes = room.strokes.slice(-2000);
    socket.to(room.code).emit("drawing:stroke", safe);
  });
  socket.on("drawing:sync", ({ code }) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (room) socket.emit("drawing:history", room.strokes);
  });
  socket.on("drawing:clear", ({ code }) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room || room.drawerId !== socket.id) return;
    room.strokes = [];
    io.to(room.code).emit("drawing:cleared");
  });
  socket.on("words:add", ({ code, words }, cb = () => {}) => {
    const room = rooms.get(String(code || "").toUpperCase());
    if (!room || room.hostId !== socket.id || room.phase !== "lobby") return cb({ ok: false, error: "Nur der Host kann in der Lobby Begriffe hinzufügen." });
    const incoming = String(words || "").split(/[\n,;]+/).map(w => w.trim()).filter(w => w.length >= 2 && w.length <= 40).slice(0, 100);
    room.customWords.push(...incoming);
    cb({ ok: true, count: incoming.length });
    broadcast(room);
  });
  socket.on("disconnect", () => {
    for (const room of rooms.values()) {
      const player = room.players.get(socket.id);
      if (player) {
        player.connected = false;
        if (room.hostId === socket.id) {
          const next = [...room.players.values()].find(p => p.connected);
          if (next) room.hostId = next.id;
        }
        broadcast(room);
        setTimeout(() => {
          const current = room.players.get(socket.id);
          if (current && !current.connected) {
            room.players.delete(socket.id);
            if (room.players.size === 0) {
              clearTimeout(room.roundTimer); clearTimeout(room.nextTimer);
              rooms.delete(room.code);
            } else broadcast(room);
          }
        }, 60000);
      }
    }
  });
});
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`Montagsmaler läuft auf Port ${PORT}`));
