# Montagsmaler Online

Ein browserbasiertes Multiplayer-Zeichenspiel für 2–8 Freunde mit privaten Räumen, Einladungscode, gemeinsamer Zeichenfläche, Chat, Rangliste und eigenen Begriffen.

## Lokal starten

Benötigt Node.js 18 oder neuer.

```bash
npm install
npm start
```

Dann `http://localhost:3000` öffnen. Zum Testen mehrerer Spieler: mehrere Browserfenster oder Geräte im selben Netzwerk verwenden (bei anderen Geräten die lokale IP-Adresse des Computers und Port 3000 öffnen; die Firewall muss den Port erlauben).

## Online veröffentlichen (z. B. Render)

1. Dieses Projekt in ein eigenes GitHub-Repository hochladen.
2. Bei Render einen neuen **Web Service** aus dem Repository erstellen.
3. Build command: `npm install`
4. Start command: `npm start`
5. Node-Version 18 oder neuer auswählen und deployen.
6. Den HTTPS-Link mit Freunden teilen. Jeder öffnet den Link, der Host erstellt einen Raum und teilt den fünfstelligen Code.

Socket.IO läuft über denselben Webserver; bei einem einzelnen Web-Service ist keine separate Echtzeit-Datenbank nötig.

## Spielregeln

- 2–8 Spieler pro privatem Raum.
- Der Host startet, wenn mindestens zwei Spieler im Raum sind.
- Pro Runde zeichnet eine Person 80 Sekunden lang; die anderen raten im Chat.
- Standardbegriffe sind integriert; der Host kann in der Lobby zusätzliche Wörter eingeben.
- Punkte und Rangliste werden während des Spiels aktualisiert.

## Hinweise / aktueller Umfang

Dies ist eine lauffähige erste Version. Räume und Spielstände werden im Arbeitsspeicher des Servers gehalten und gehen bei einem Server-Neustart verloren. Das Spiel ist für kleine private Runden gedacht, nicht als gehärteter öffentlicher Dienst. Für eine spätere Version wären persistente Räume, reconnect-resistente Spieler-IDs, konfigurierbare Rundenzahl, serverseitig präzisere Timer/Punkte und Moderationsfunktionen sinnvolle Ergänzungen.
