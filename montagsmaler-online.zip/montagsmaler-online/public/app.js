const socket = io();
const $ = id => document.getElementById(id);
const sections = ["home","lobby","game","finished"];
let state = { code:null, playerId:null, hostId:null, drawerId:null, isDrawer:false, phase:"home", room:null, word:null, timeLeft:80, timerInterval:null, color:"#172033", width:5, eraser:false, drawing:false, last:null, scaleX:1, scaleY:1 };
const canvas = $("drawingBoard"), ctx = canvas.getContext("2d");
function showSection(id){sections.forEach(s=>$(s).classList.toggle("hidden",s!==id));state.phase=id;window.scrollTo({top:0,behavior:"smooth"});}
function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2400)}
function name(){return $("playerName").value.trim()||"Picasso";}
function setError(id,msg){$(id).textContent=msg||""}
function emitAck(event,data){return new Promise(resolve=>socket.emit(event,data,resolve))}
socket.on("connect",()=>{$("connection").textContent="Online";});
socket.on("disconnect",()=>{$("connection").textContent="Verbindung unterbrochen";});
$("createRoom").onclick=async()=>{setError("homeError","");const res=await emitAck("room:create",{name:name()});if(res.ok){state.code=res.code;state.playerId=res.playerId;showSection("lobby");$("shownCode").textContent=res.code;toast("Raum erstellt! Teile den Code mit deinen Freunden.");}else setError("homeError",res.error||"Raum konnte nicht erstellt werden.")};
$("joinRoom").onclick=async()=>{setError("homeError","");const code=$("roomCode").value.trim().toUpperCase();if(code.length!==5){setError("homeError","Bitte gib einen fünfstelligen Raum-Code ein.");return;}const res=await emitAck("room:join",{code,name:name()});if(res.ok){state.code=res.code;state.playerId=res.playerId;showSection("lobby");$("shownCode").textContent=res.code;toast("Du bist dem Raum beigetreten!");}else setError("homeError",res.error||"Beitritt fehlgeschlagen.")};
$("roomCode").addEventListener("input",e=>e.target.value=e.target.value.toUpperCase().replace(/[^A-Z0-9]/g,"").slice(0,5));
$("copyCode").onclick=async()=>{try{await navigator.clipboard.writeText(state.code);toast("Raum-Code kopiert!")}catch{toast("Dein Raum-Code: "+state.code)}};
$("leaveLobby").onclick=()=>{state.code=null;state.playerId=null;showSection("home")};
$("startGame").onclick=async()=>{setError("lobbyError","");const r=await emitAck("game:start",{code:state.code});if(!r.ok)setError("lobbyError",r.error)};
$("saveWords").onclick=async()=>{const words=$("customWords").value.trim();if(!words)return toast("Gib zuerst eigene Begriffe ein.");const r=await emitAck("words:add",{code:state.code,words});if(r.ok){$("customWords").value="";$("wordsStatus").textContent=`${r.count} Begriffe hinzugefügt.`;toast(`${r.count} Begriffe hinzugefügt!`)}else $("wordsStatus").textContent=r.error||"Konnte Begriffe nicht speichern."};
socket.on("room:update",room=>{if(state.code!==room.code)return;state.room=room;state.hostId=room.hostId;state.drawerId=room.drawerId;state.isDrawer=room.drawerId===state.playerId;
  $("shownCode").textContent=room.code;$("playerCount").textContent=`${room.players.length}/8`;
  $("players").innerHTML=room.players.map((p,i)=>`<div class="player-row"><span class="player-avatar">${escapeHtml(p.name[0].toUpperCase())}</span><span class="player-name">${escapeHtml(p.name)}${p.connected?"":" (offline)"}</span>${p.id===room.hostId?'<span class="host-tag">HOST</span>':''}${p.connected?'<span class="status-dot"></span>':''}</div>`).join("");
  $("startGame").classList.toggle("hidden",room.hostId!==state.playerId);
  $("hostNote").textContent=room.hostId===state.playerId?"Du bist der Host dieses Raums.":"Der Host startet das Spiel.";
  if(room.phase==="lobby"||room.phase==="finished"&&state.phase==="lobby"){if(state.phase!=="lobby")showSection("lobby");}
  if(["playing","reveal"].includes(room.phase)){if(state.phase!=="game")showSection("game");$("roundNumber").textContent=room.round;$("gameTitle").textContent=room.phase==="playing"?"Wer errät den Begriff?":"Auflösung!";$("wordDisplay").textContent=state.isDrawer&&state.word?state.word:(room.phase==="reveal"?"Begriff aufgelöst":room.maskedWord||"Rate mit!");$("drawerLabel").textContent=(room.players.find(p=>p.id===room.drawerId)?.name||"Spieler")+" zeichnet";$("drawingHint").textContent=state.isDrawer?"Du zeichnest – die anderen raten!":"Rate den Begriff im Chat!";$("chatInput").placeholder=state.isDrawer?"Chatte mit den anderen…":"Dein Tipp…";}
  renderScores(room.players);renderMessages(room.messages);
  if(room.phase==="finished")showSection("finished");
});
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderScores(players){$("scoreList").innerHTML=[...players].sort((a,b)=>b.score-a.score).map((p,i)=>`<div class="score-row"><span class="rank ${i===0?"first":""}">${i===0?"♛":i+1}</span><span class="player-avatar">${escapeHtml(p.name[0].toUpperCase())}</span><span class="player-name">${escapeHtml(p.name)}</span><span class="score-points">${p.score}</span></div>`).join("")}
function renderMessages(messages){const el=$("chatMessages");el.innerHTML=(messages||[]).slice(-60).map(m=>m.system?`<div class="chat-msg system">${escapeHtml(m.text)}</div>`:`<div class="chat-msg"><b>${escapeHtml(m.name)}:</b>${escapeHtml(m.text)}</div>`).join("");el.scrollTop=el.scrollHeight}
socket.on("chat:message",m=>{if(!state.room)return;const el=$("chatMessages");const div=document.createElement("div");div.className="chat-msg";div.innerHTML=`<b>${escapeHtml(m.name)}:</b>${escapeHtml(m.text)}`;el.appendChild(div);el.scrollTop=el.scrollHeight});
socket.on("word:private",data=>{state.word=data.word;state.isDrawer=true;$("wordDisplay").textContent=data.word;$("drawingHint").textContent="Du zeichnest – die anderen raten!";toast("Dein Begriff: "+data.word)});
socket.on("round:started",data=>{state.word=null;state.drawerId=data.drawerId;state.isDrawer=data.drawerId===state.playerId;state.timeLeft=data.duration||80;clearInterval(state.timerInterval);startTimer();clearCanvasLocal();$("roundNumber").textContent=data.round;$("drawerLabel").textContent=data.drawerName+" zeichnet";$("wordDisplay").textContent=state.isDrawer?"Begriff wird geladen…":"_ ".repeat(data.wordLength).trim();$("drawingHint").textContent=state.isDrawer?"Du zeichnest – die anderen raten!":"Rate den Begriff im Chat!";showSection("game");socket.emit("drawing:sync",{code:state.code})});
function startTimer(){clearInterval(state.timerInterval);const update=()=>{$("timer").textContent=`${Math.floor(state.timeLeft/60)}:${String(state.timeLeft%60).padStart(2,"0")}`;if(state.timeLeft<=0){clearInterval(state.timerInterval);return;}state.timeLeft--};update();state.timerInterval=setInterval(update,1000)}
socket.on("round:ended",({word,reason})=>{state.word=word;state.isDrawer=false;$("wordDisplay").textContent=word;$("gameTitle").textContent=reason==="Begriff erraten"?"Richtig geraten!":"Zeit abgelaufen!";clearInterval(state.timerInterval);toast("Der Begriff war: "+word)});
socket.on("game:finished",({players})=>{$("finalScores").innerHTML=players.map((p,i)=>`<div class="final-score"><span class="rank ${i===0?"first":""}">${i===0?"🏆":i+1}</span><b>${escapeHtml(p.name)}</b><strong>${p.score} Punkte</strong></div>`).join("");showSection("finished")});
$("backHome").onclick=()=>{state.code=null;state.playerId=null;state.room=null;state.word=null;showSection("home")};
$("chatForm").onsubmit=e=>{e.preventDefault();const text=$("chatInput").value.trim();if(!text||!state.code)return;socket.emit("chat:send",{code:state.code,text});$("chatInput").value=""};
function clearCanvasLocal(){ctx.clearRect(0,0,canvas.width,canvas.height);ctx.fillStyle="#fff";ctx.fillRect(0,0,canvas.width,canvas.height)}
function drawStroke(s){if(s.clear){clearCanvasLocal();return}ctx.save();ctx.strokeStyle=s.color;ctx.lineWidth=s.width;ctx.lineCap="round";ctx.lineJoin="round";ctx.beginPath();ctx.moveTo(s.x0*canvas.width,s.y0*canvas.height);ctx.lineTo(s.x1*canvas.width,s.y1*canvas.height);ctx.stroke();ctx.restore()}
socket.on("drawing:stroke",drawStroke);socket.on("drawing:history",list=>{clearCanvasLocal();list.forEach(drawStroke)});socket.on("drawing:cleared",clearCanvasLocal);
function pointerPos(e){const r=canvas.getBoundingClientRect();return{x:Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),y:Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))}}
canvas.addEventListener("pointerdown",e=>{if(!state.isDrawer||!state.code)return;state.drawing=true;state.last=pointerPos(e);canvas.setPointerCapture(e.pointerId)});
canvas.addEventListener("pointermove",e=>{if(!state.drawing||!state.last)return;const p=pointerPos(e);const stroke={x0:state.last.x,y0:state.last.y,x1:p.x,y1:p.y,color:state.eraser?"#ffffff":state.color,width:state.eraser?24:state.width};drawStroke(stroke);socket.emit("drawing:stroke",{code:state.code,stroke});state.last=p});
function stopDrawing(){state.drawing=false;state.last=null}canvas.addEventListener("pointerup",stopDrawing);canvas.addEventListener("pointercancel",stopDrawing);canvas.addEventListener("pointerleave",e=>{if(e.buttons===0)stopDrawing()});
$("colorPicker").oninput=e=>{state.color=e.target.value;state.eraser=false;$("eraserTool").classList.remove("active");$("penTool").classList.add("active")};
$("penTool").onclick=()=>{state.eraser=false;$("penTool").classList.add("active");$("eraserTool").classList.remove("active")};
$("eraserTool").onclick=()=>{state.eraser=true;$("eraserTool").classList.add("active");$("penTool").classList.remove("active")};
$("clearBoard").onclick=()=>{if(!state.isDrawer)return toast("Nur der Zeichner kann die Tafel leeren.");socket.emit("drawing:clear",{code:state.code});clearCanvasLocal()};
clearCanvasLocal();
